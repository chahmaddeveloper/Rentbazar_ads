<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>All Classifieds</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-select.css">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="css/jquery-ui1.css">
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> 
	addEventListener("load", function() 
	{ 
		setTimeout(hideURLbar, 0); 
	}, 
	false); 
	function hideURLbar()
	{ 
		window.scrollTo(0,1); 
	}
	</script>
<!-- //for-mobile-apps -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
<!-- js -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-select.js"></script>
<script>
  $(document).ready(function () 
  {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () 
    {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () 
    {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker(
    {
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
<link href="css/jquery.uls.css" rel="stylesheet"/>
<link href="css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="js/jquery.uls.data.js"></script>
<script src="js/jquery.uls.data.utils.js"></script>
<script src="js/jquery.uls.lcd.js"></script>
<script src="js/jquery.uls.languagefilter.js"></script>
<script src="js/jquery.uls.regionfilter.js"></script>
<script src="js/jquery.uls.core.js"></script>
<script>
	$( document ).ready( function() {
	
	} );
</script>
<script src="js/tabs.js"></script>	
<script type="text/javascript">
	$(document).ready(function() 
	{    
	});
</script>
<style>
	table
	{
	    margin-left: 25%
	}
            table, th, td {
                border: 1px solid black;
                border-collapse: collapse;
            }
            th, td {
                padding: 5px;
                text-align: left;    
            }

            #im {
                
                width: 30%;
                height: 30%;
                
            }
          #page {
              margin-left: 10px;
          }
</style>
</head>
<body>
<div class="header">
		<div class="container">
			<div class="logo">
				<a href="index.php"><span>Rent</span>Bazaar</a>
			</div>
			
		</div>
	</div>


	<div class="total-ads main-grid-border">
		<div class="container">
			<div class="select-box">
                <form method="post">
				<div class="browse-category ads-list" style="margin-left: 10%">
					<label>Browse Categories</label>
					<select class="selectpicker show-tick" name="s1">
						<option data-tokens="All">All</option>
						<option data-tokens="Mobiles">Mobiles</option>
						<option data-tokens="Electronics">Electronics</option>
						<option data-tokens="Cars">Cars</option>
						<option data-tokens="Bikes">Bikes</option>
						<option data-tokens="Books">Books</option>
	                    <option data-tokens="Cameras">Cameras</option>
					</select>
				</div>
				<div class="search-product ads-list" style="margin-left: 10%">
					<label>Search for a specific product</label>
					<div class="search">
						<div id="custom-search-input">
						<div class="input-group">
							<input type="search" class="form-control input-lg"   name="s2" />
							<span class="input-group-btn">
								<input class="btn btn-info btn-lg" type="submit" value="Search" name="BTNSearch" />
							        
							</span>
						</div>
					</div>
					</div>
				</div>
                </form>
				<div class="clearfix"></div>
			</div>
		</div>	
	</div>
	<div class="ads-display col-md-9">
		<div class="wrapper">					
			<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
					<ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
						<li role="presentation" class="active">
							<a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" 	aria-expanded="true">
							<span class="text">All Ads</span>
						  	</a>
						</li>
					</ul>
					<div id="myTabContent" class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
						   <div>
												<div id="container">
								
								
								<div class="clearfix"></div>
							<ul class="list">
								
							
							
								
<?php    
    include("config.php");
        $q="";
        $q1="";
        if( isset($_POST['BTNSearch']) )
	 	{
	 		$category = $_POST['s1'];
	 		$TxtSrch  = $_POST['s2'];
	        if( $TxtSrch == "" )
	        {
	        	if($category == "all")
	        	{
	        		$q  ="SELECT * FROM item_post WHERE status = 1 ";
			        $q1 ="SELECT * FROM item_post WHERE status = 1  ORDER BY item_id ";
	        	}
	        	else
	        	{
		        	$q  ="SELECT * FROM item_post WHERE catagory = '$category' 
		        	AND status = 1 ORDER BY item_id ";
			        $q1 ="SELECT * FROM item_post WHERE catagory = '$category' 
			        AND status = 1 ORDER BY item_id ";
	        	}
	        }
	        else
	        {
	        	if($category == "all")
	        	{
	        		$q ="SELECT * FROM item_post WHERE  
			        item_name = '$TxtSrch' AND status = 1 ORDER BY item_id ";
			        $q1 ="SELECT * FROM item_post WHERE 
			        item_name = '$TxtSrch' AND status = 1 ORDER BY item_id ";
	        	}
	        	else
	        	{
	        		$q ="SELECT * FROM item_post WHERE catagory = '$category' AND 
		        	item_name = '$TxtSrch' AND status = 1 ORDER BY item_id ";
		        	$q1 ="SELECT * FROM item_post WHERE catagory = '$category' AND 
		        	item_name = '$TxtSrch' AND status = 1 ORDER BY item_id ";	
	        	}
	        }
	        
	    }
	    else
	    {    
	        $q = "SELECT * FROM item_post WHERE status = 1 ORDER BY item_id ";
	        $q1 = "SELECT * FROM item_post WHERE status = 1 ORDER BY item_id ";
	    }
	    
	    $excecute = mysqli_query($conn,$q);

	    if($excecute) 
	    {
	        
	    	while( $row = mysqli_fetch_array( $excecute) )
	    	{

	            $link = $row['item_img'];
	            $price = $row['price'];
	            $item_name = $row['item_name'];
	    
	            $posted = $row['posted'];
	            $descript = $row['decription'];
	            $city = $row['city'];

	            $rent = $row['rent'];
	            $contact = $row['contact'];


	            if($rent=='n')
	            {
	                $rent="Available For Rent";
	            }
	            else
	            {
	                $rent="Not Available For Rent";
	            }
	        	echo'
					<li>
						<img src="'.$link.'" title="" alt="" />
						<section class="list-left">
						<h5 class="title">'.$item_name.'</h5>
						<span class="adprice">Rent Per Day : '.$price.'</span>
	                    <span class="adprice">'.$descript.'</span>

						<p class="catpath">'.$rent.'</p>
						</section>
						<section class="list-right">
						<span class="cityname">'.$city.' : ('.$contact.')</span>
						</section>
						<div class="clearfix"></div>
					</li>
				';
	    	}
	    }
	   	$excecute = mysqli_query($conn,$q1);
	    
	    if($excecute) 
	    {
	    	$count = 0;
	        while( $row = mysqli_fetch_array($excecute))
	    	{
	        	$count = $count + 1;
	    	}
	 	}		   
?>

							</ul>
						</div>
							</div>
						</div>
						
						<ul class="pagination pagination-sm">
                     
	<?php        
	for($i=0; $i<ceil($count/3); $i++)
	{        
        echo'    <li><a href="all_ads.php?page='.($i+1).'">'.($i+1).'</a></li>';
	}
    ?>
						</ul>
					  </div>
					</div>
				</div>
				</div>
		<footer>
			<div class="footer-top">
				<div class="container">
					<div class="foo-grids">
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Who We Are</h4>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
							<p>The point of using Lorem Ipsum is that it has a more-or-less normal letters, as opposed to using 'Content here.</p>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Help</h4>
							<ul>
							
								<li><a href="#">Feedback</a></li>
						
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Information</h4>
							<ul>
				 
								<li><a href="#">Privacy Policy</a></li>	
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Contact Us</h4>
							<span class="hq">Our headquarters</span>
							<address>
								<ul class="location">
									<li><span class="glyphicon glyphicon-map-marker"></span></li>
									<li>View hotel Comsats Road</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-earphone"></span></li>
									<li>+0 561 111 235</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-envelope"></span></li>
									<li><a href="mailto:info@example.com">CIITSahiwal@gmail.com</a></li>
									<div class="clearfix"></div>
								</ul>						
							</address>
						</div>
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="footer-bottom text-center">
			<div class="container">
				<div class="footer-logo">
					<a href="index.php"><span>Rent</span>Bazaar</a>
				</div>
				<div class="footer-social-icons">
					<ul>
						<li><a class="facebook" href="#"><span>Facebook</span></a></li>
						<li><a class="twitter" href="#"><span>Twitter</span></a></li>
						<li><a class="googleplus" href="#"><span>Google+</span></a></li>
						
					</ul>
				</div>
				<div class="copyrights">
					<p> © <?php echo date("Y"); ?> Rent Bazaar. All Rights Reserved </p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->
</body>
</html>