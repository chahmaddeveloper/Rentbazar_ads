<?php
    session_start();
    include("config.php");
    include("header.php");
?>
    <div class="main-banner banner text-center">
      <div class="container">    
            <h1>Rent or Advertise   <span class="segment-heading">    anything online </span> with RentBazaar</h1>
          <p>This is a simple startup for Exchanigng goods on rent</p>

            <a href="post_ads.php" style="margin-top:10px ">Post Free Ad</a>
      </div>
    </div>
        

        <!-- content-starts-here -->
        <div class="content">
            <div class="categories">
                <div class="container">
                    <div class="col-md-2 focus-grid" >
                        <a href="all_ads.php?cat=Mobiles">
                            <div class="focus-border">
                                <div class="focus-layout">
                                    <div class="focus-image"><i class="fa fa-mobile"></i></div>
                                    <h4 class="clrchg">Mobiles</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-2 focus-grid">
                        <a href="all_ads.php?cat=Electronics">
                            <div class="focus-border">
                                <div class="focus-layout">
                                    <div class="focus-image"><i class="fa fa-laptop"></i></div>
                                    <h4 class="clrchg"> Electronics</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-2 focus-grid">
                        <a href="all_ads.php?cat=Cars">
                            <div class="focus-border">
                                <div class="focus-layout">
                                    <div class="focus-image"><i class="fa fa-car"></i></div>
                                    <h4 class="clrchg">Cars</h4>
                                </div>
                            </div>
                        </a>
                    </div>    
                    <div class="col-md-2 focus-grid">
                        <a href="all_ads.php?cat=Bikes">
                            <div class="focus-border">
                                <div class="focus-layout">
                                    <div class="focus-image"><i class="fa fa-motorcycle"></i></div>
                                    <h4 class="clrchg">Bikes</h4>
                                </div>
                            </div>
                        </a>
                    </div>    
                    
                        
                    <div class="col-md-2 focus-grid">
                        <a href="all_ads.php?cat=Books">
                            <div class="focus-border">
                                <div class="focus-layout">
                                    <div class="focus-image"><i class="fa fa-book"></i></div>
                                    <h4 class="clrchg">Books</h4>
                                </div>
                            </div>
                        </a>
                    </div>    

                        
                    <div class="col-md-2 focus-grid">
                        <a href="all_ads.php?cat=Cameras">
                            <div class="focus-border">
                                <div class="focus-layout">
                                    <div class="focus-image"><i class="fa fa-camera"></i></div>
                                    <h4 class="clrchg">Cameras</h4>
                                </div>
                            </div>
                        </a>
                    </div>    
                    <div class="clearfix"></div>
                </div>
            </div>            
            <div class="mobile-app">
                <div class="container">
                    <div class="col-md-5 app-left">
                        <a href="all_ads.php"><img src="images/app_front.png" alt=""></a>
                    </div>
                    <div class="col-md-7 app-right">
                        <h3>RentBazaar App is the <span>Easiest</span> way for Renting goods</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam auctor Sed bibendum varius euismod. Integer eget turpis sit amet lorem rutrum ullamcorper sed sed dui. vestibulum odio at elementum. Suspendisse et condimentum nibh.</p>
                        <div class="app-buttons">
                            <div class="app-button">
                                <a href="#"><img src="images/1.png" alt=""></a>
                            </div>
                            
                            <div class="clearfix"> </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        
        <?php include("footer.php"); ?>
</body>
</html>



