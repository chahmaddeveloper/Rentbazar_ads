<?php
session_start();
include("config.php");
if(!isset($_SESSION['id']))
{
    header("location:login.php");
}
if(!empty($_GET['item_id']))
{
    $Query = mysqli_query($conn,"SELECT * FROM item_post WHERE item_id = ".$_GET['item_id']." ");
    if(mysqli_num_rows($Query) > 0)
    {
        $ItemID = $_GET['item_id'];
        $Data = mysqli_fetch_array($Query);
    }
}
if(isset($_POST['post']) && isset($_SESSION['id'])) 
{
    $p9 = $_SESSION['id'];
    
    $p1 = $_POST['p1'];
    
    $p2 = $_POST['p2'];
    $p3 = $_POST['p3'];
    $p4 = "";
    $p5 = $_POST['p5'];
    
    $allowed = array(
        'png',
        'jpg',
        'gif',
        'jpeg'
    );   
    if (isset($_FILES['upl']) && $_FILES['upl']['error'] == 0) 
    {
        $extension = pathinfo($_FILES['upl']['name'], PATHINFO_EXTENSION);
        
        if (!in_array(strtolower($extension), $allowed)) 
        {
            
        }
        if (move_uploaded_file($_FILES['upl']['tmp_name'], 'uploads/' . $_FILES['upl']['name'])) 
        {
            $p4 =  $_FILES['upl']['name'];
            
            $q2  = "UPDATE item_post SET 
            catagory   = '$p1',
            item_name  = '$p2',
            decription = '$p3',
            item_img   = '$p4', 
            price      = $p5
            WHERE item_id = ".$ItemID." ";
            $run = mysqli_query($conn, $q2);
            if ($run) 
            {
                echo '<script type="text/javascript">
                  alert("Ad Post Successfull");
                 </script>';
                 header("location:my_ads.php");
            }
            else 
            {
                echo '<script type="text/javascript">
                  alert("Not Inserted");
                 </script>';
            }
        }
    }
    else
    {

        $q2  = "UPDATE item_post SET 
        catagory   = '$p1',
        item_name  = '$p2',
        decription = '$p3',
        price      = $p5
        WHERE item_id = ".$ItemID." ";
        $run = mysqli_query($conn, $q2);
        if ($run) 
        {
            echo '<script type="text/javascript">
              alert("Ad Post Successfull");
             </script>';
             header("location:my_ads.php");
        }
        else 
        {
            echo '<script type="text/javascript">
              alert("Not Inserted");
             </script>';
        }
    }

               
}

include("header.php");
?>


    <div class="banner text-center">
      <div class="container">    
            <h1>Rent or Advertise   <span class="segment-heading">    anything online </span> with RentBazaar</h1>
            
      </div>
    </div>
    <!-- Submit Ad -->
    <div class="submit-ad main-grid-border">
        <div class="container">
            <h2 class="head">Post an Ad</h2>
            <div class="post-ad-form">
                <form action="#" method="POST" enctype="multipart/form-data">
                    <label>Select Category <span>*</span></label>
                    <select class="" name="p1" required=" ">
                      <option><?=$Data['catagory']; ?></option>
                      <option>Select Category</option>
                      <option>Mobiles</option>
                      <option>Electronics</option>
                      <option>Cars</option>
                      <option>Bikes</option>
                      <option>Books</option>
                      <option>Cameras</option>
                     
                    </select>

                    <div class="clearfix"></div>
                    <label>Item name <span>*</span></label>
                    <input type="text" class="phone" value="<?=$Data['name']; ?>" name="p2" required=" ">
                    <div class="clearfix"></div>

                    <label>Item  Description <span>*</span></label>
                    <textarea class="mess" required=" " name="p3"><?=$Data['decription'];?></textarea>
                    <div class="clearfix"></div>

                <div class="upload-ad-photos">
                <label>Change Photos for your ads:</label>    
                    <div class="photos-upload-view">
                        <div>
                            <input type="file"  name="upl" />
                            <img src="uploads/<?=$Data['item_img']; ?>" style="width: 90px; height: 70px;" />
                        </div>
                    </div>
                    <div class="clearfix"></div>
                        
                </div>
                    <div class="personal-details">
                    
                        <label>Rent Per Day<span>*</span></label>
                        <input type="text" class="name" required=" " value="<?=$Data['price']; ?>" name="p5">
                        <div class="clearfix"></div>
                        
                    <input type="submit" value="Update Post" name="post">                    
                    <div class="clearfix"></div>
                    
                    </div>
                    </form>
            </div>
        </div>    
    </div>
    <?php include("footer.php"); ?>
</body>
</html>


