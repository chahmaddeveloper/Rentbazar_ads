ha
<?php
session_start();

if (!isset($_SESSION['id']))
{
    header("location:/login.php");
}
else
{
   echo $item_id=$_GET['item_id'];
   echo $rent=$_GET['rent'];

  include("config.php");
  if($conn)
  {
    $q ="";
    $q =" UPDATE Item_Post 
    SET rent = '$rent' 
    WHERE item_id ='$item_id'";

    $excecute = mysqli_query($conn,$q);

    if($excecute)
    {
        header("location:my_ads.php");
    }
  }
}

?>

