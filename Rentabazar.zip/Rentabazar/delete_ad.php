<?php
session_start();
if (!isset($_SESSION['id']))
{
    header("location:login.php");
}
else
{
   	echo $item_id = $_GET['item_id'];  
   	include("config.php");
   	if($conn)
    {
        $q="";
        $q=" DELETE FROM Item_Post  WHERE item_id = '$item_id'";

        $excecute= mysqli_query($conn,$q);

        if($excecute)
        {

            header("location:my_ads.php");
        }
     }
}
?>

