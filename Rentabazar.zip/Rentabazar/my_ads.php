<?php
	session_start();
	include("header.php");
?>	
	<div class="ads-display col-md-9">
		<div class="wrapper">					
		<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
		  <ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
			<li role="presentation" class="active">
			  <a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">
				<span class="text">All Ads</span>
			  </a>
			</li>
			
		  </ul>
		  <div id="myTabContent" class="tab-content">
			<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
			   <div>
									<div id="container">
					
					
					<div class="clearfix"></div>
				<ul class="list">
								
    <?php
	$id=0;

   	$id = $_SESSION['id'];
   	include("config.php");
   	if($conn)
    {
        $q="";
        $q1="";
        $q = "SELECT * FROM Item_Post WHERE id ='$id' AND status = 1 ";

        $excecute= mysqli_query($conn,$q);

        if($excecute)
        {

            while( $row = mysqli_fetch_array( $excecute ) )
        	{
	            $link = 'uploads/'.$row['item_img'];
	            $price = $row['price'];
	            $item_name = $row['item_name'];
	            $posted = $row['posted'];
	            $descript = $row['decription'];
	            $city = $row['city'];
	            $rent = $row['rent'];
	            $item_id = $row['item_id'];
	            $contact = $row['contact'];
            if($rent=='n')
            {
                $rent="Available For Rent";
                echo '<a href="change_rent_status.php?item_id='.$item_id.'& rent=y"><h1> Rent(Yes)</h1>  </a>';
            }
            else
            {
                $rent="Not Available For Rent";
                echo '<a href="change_rent_status.php?item_id='.$item_id.'&rent=n"><h1>Rent(No) </h1>  </a>';
            }
            echo '<a href="delete_ad.php?item_id='.$item_id.'"><h4>Delete Ad</h4>  </a>';
            echo '<a href="post_update.php?item_id='.$item_id.'"><h4>Update Ad</h4>  </a>';
            echo'
				<li>
					<img src="'.$link.'" title="" alt="" />
					<section class="list-left">
					<h5 class="title">'.$item_name.'</h5>
					<span class="adprice">Rent Per Day : '.$price.'</span>
                    <span class="adprice">'.$descript.'</span>

					<p class="catpath">'.$rent.'</p>
					</section>
					<section class="list-right">
					<span class="cityname">'.$city.' : ('.$contact.')</span>
					</section>
					<div class="clearfix"></div>
					</li>

                ';
        }


        }
	}
  ?>
							
							</ul>
						</div>
							</div>
						</div>
						
				
					  </div>
					</div>
				</div>
				</div>
		<?php include('footer.php'); ?>
</body>
</html>
