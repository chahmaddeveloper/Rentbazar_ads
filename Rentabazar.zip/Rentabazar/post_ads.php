<?php
session_start();
include("config.php");
if(!isset($_SESSION['id']))
{
    header("location:login.php");
}

if(isset($_POST['post']) && isset($_SESSION['id'])) 
{
    $p9 = $_SESSION['id'];
    
    $p1 = $_POST['p1'];
    
    $p2 = $_POST['p2'];
    $p3 = $_POST['p3'];
    $p4 = "";
    $p5 = $_POST['p5'];
    
    $allowed = array(
        'png',
        'jpg',
        'gif',
        'jpeg'
    );   
    if (isset($_FILES['upl']) && $_FILES['upl']['error'] == 0) 
    {
        $extension = pathinfo($_FILES['upl']['name'], PATHINFO_EXTENSION);
        
        if (!in_array(strtolower($extension), $allowed)) 
        {
            //echo '{"status":"error"}';
            //exit;
        }
        
        if (move_uploaded_file($_FILES['upl']['tmp_name'], 'uploads/' . $_FILES['upl']['name'])) {
            //echo '{"status":"success"}';
            $p4 =  $_FILES['upl']['name'];
            
        }
    }

    if($conn) 
    {
        $p6 = "";
        $p7 = "";
        $p8 = "";
        
        $q1       = "SELECT  * FROM info where id = $p9 ";
        $excecute = mysqli_query($conn, $q1);
        if ($excecute) 
        {
            while ($row = mysqli_fetch_array($excecute)) 
            {      
                $p6 = $row['city'];
                $p7 = $row['name'];
                $p8 = $row['contact'];
            }
        } 
        else 
        {
            echo '<script type="text/javascript">
              alert("Error");
             </script>';
            
        }
        
        $q2  = "INSERT INTO item_post VALUES(Null, '$p1','$p2','$p3','$p4', $p5,'$p6','$p7','$p8', 
        $p9, 'n', 0, '".date("Y/m/d")."' )";
        $run = mysqli_query($conn, $q2);
        if ($run) 
        {
            echo '<script type="text/javascript">
              alert("Ad Post Successfull");
             </script>';
             header("location:all_ads.php");
        }
        else 
        {
            echo '<script type="text/javascript">
              alert("Not Inserted");
             </script>';
        }   
    }    
}

include("header.php");
?>


    <div class="banner text-center">
      <div class="container">    
            <h1>Rent or Advertise   <span class="segment-heading">    anything online </span> with RentBazaar</h1>
            
      </div>
    </div>
    <!-- Submit Ad -->
    <div class="submit-ad main-grid-border">
        <div class="container">
            <h2 class="head">Post an Ad</h2>
            <div class="post-ad-form">
                <form action="#" method="POST" enctype="multipart/form-data">

                    <label>Select Category <span>*</span></label>
                    <select class="" name="p1" required=" ">
                      <option>Select Category</option>
                      <option>Mobiles</option>
                      <option>Electronics</option>
                      <option>Cars</option>
                      <option>Bikes</option>
                      <option>Books</option>
                      <option>Cameras</option>
                     
                    </select>

                    <div class="clearfix"></div>
                    <label>Item name <span>*</span></label>
                    <input type="text" class="phone" placeholder="" name="p2" required=" ">
                    <div class="clearfix"></div>

                    <label>Item  Description <span>*</span></label>
                    <textarea class="mess" placeholder="Write few lines about your product" required=" " name="p3"></textarea>
                    <div class="clearfix"></div>

                <div class="upload-ad-photos">
                <label>Photos for your ad :</label>    
                    <div class="photos-upload-view">
                        
                        
                        <div>
                            <input type="file"  name="upl" required=" " />
                            
                        </div>

                        
                        

                        </div>
                    <div class="clearfix"></div>
                        
                </div>
                    <div class="personal-details">
                    
                        <label>Rent Per Day<span>*</span></label>
                        <input type="text" class="name" required=" " placeholder="" name="p5">
                        <div class="clearfix"></div>
                        
                    <input type="submit" value="Post" name="post">                    
                    <div class="clearfix"></div>
                    
                    </div>
                    </form>
            </div>
        </div>    
    </div>
    <?php include("footer.php"); ?>
</body>
</html>


