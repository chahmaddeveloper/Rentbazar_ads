<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
        <style>
                    table
                    {
                        margin-left: 25%
                    }
            table, th, td {
                border: 1px solid black;
                border-collapse: collapse;
            }
            th, td {
                padding: 5px;
                text-align: left;    
            }

            #im {
                
                width: 30%;
                height: 30%;
            }
        </style>

    </head>
    <body>
       


    </body>
</html>

<?php
include("config.php");

if($conn)
{
     $q = "SELECT * FROM Item_Post";


        $excecute= mysqli_query($conn,$q);


        if($excecute)
        {


           echo' <table style="width:50%">
                <tr>
                    <th>Visitor Name</th>
                    <th>Visitor</th>
                    <th>Visitor CNIC</th>
                    <th>Vehicle NO</th>
                    <th>Duration</th>
                </tr>
            ';

                $count=0;
             while( $row = mysqli_fetch_array( $excecute) )
        {
            $count++;
        }
          echo $count;
               $excecute= mysqli_query($conn,$q);




             while( $row = mysqli_fetch_array( $excecute) )
        {


            echo "<br>";

            echo '<tr>';

            echo '<td>'.$row['id'].'</td>';
            echo '<td>'.$row['name'].'</td>';
            echo '<td>'.$row['item_img'].'</td>';
             echo '<td>'.$row['price'].'</td>';
            echo '<td>'.$row['contact'].'</td>';

      echo '</ >';
    //  echo"<img id=\"im\" src=\"".$row['item_img']."\">";
        }


        }



     }

?>


