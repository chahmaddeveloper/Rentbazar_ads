<style>

    #main {
    
    color: #ffd800;
    text-align: right;
    margin-left: 50px;
    }
    #lt1
    {   
       background-color: #ffd800;
       float: right;
       clear: left
    }
    #lt1:hover
    {
        
       background-color: #fff;
       float: right;
       margin-left: 0px;
    }
    
    #lt2
    {
        
       background-color: #ffd800;
       float: right;
       clear: left
    }
    
   
    
    #lt2:hover
    {
        
       background-color: #fff;
       float: right;
       margin-left: 0px;
    }
   
</style>
<?php
if (isset($_SESSION['name'])) 
{
    $name = $_SESSION['name'];
    echo "<h1 id=\"main\">" . $name . "</h1>";    
}
?>
<script>
    $(document).ready(function () {

        $('#lt1').click(function () {
  
        
            var pageURL = $(location).attr("host");
           
            var full = "" + pageURL + "/rentabazar/admin/logout.php";
         //   alert(full);
        document.location="http://"+full;


        });
    });
</script>

<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-select.css">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="css/font-awesome.min.css" />
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->    
<!-- js -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-select.js"></script>
<script>
  $(document).ready(function () {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker({
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<scrip type="text/javascript" src="js/jquery.leanModal.min.js"></script>
<link href="css/jquery.uls.css" rel="stylesheet"/>
<link href="css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="js/jquery.uls.data.js"></script>
<script src="js/jquery.uls.data.utils.js"></script>
<script src="js/jquery.uls.lcd.js"></script>
<script src="js/jquery.uls.languagefilter.js"></script>
<script src="js/jquery.uls.regionfilter.js"></script>
<script src="js/jquery.uls.core.js"></script>
<script>
    $(document).ready(function () {

        $('#lt1').click(function () {
  
        
            var pageURL = $(location).attr("host");
           
            var full = "" + pageURL + "/rentabazar/admin/logout.php";
         //   alert(full);
        document.location="http://"+full;


        });
    });
        </script>
</head>
<body>
    <div class="header">
        <div class="container">
            <div class="logo">
                <a href="index.php"><span>Rent</span>Bazaar</a>
            </div>
            <?php
            if (isset($_SESSION['name'])) 
            {
            ?>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="logout.php">Log Out</a>
            </div>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="post_ads.php">Post Ads</a>
            </div>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="my_ads.php">My Ads</a>
            </div>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="all_ads.php">All Ads</a>
            </div>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="index.php">Home</a>
            </div>
            <?php
            }
            else
            {
            ?>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="login.php">Login</a>
            </div>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="all_ads.php">All Ads</a>
            </div>
            <div class="header-right" style="border: 1px solid #fff;">
                <a class="account" href="index.php">Home</a>
            </div>
            <?php  
            }
            ?>
        </div>
    </div>