<?php
	session_start();
	include("header.php");
?>
	<div class="total-ads main-grid-border">
		<div class="container">
			<div class="select-box">
                <form method="post" action="all_ads.php">
				<div class="browse-category ads-list" style="margin-left: 10%">
					<label>Browse Categories</label>
					<select class="selectpicker show-tick" name="s1">
						<option data-tokens="Mobiles">Mobiles</option>
						<option data-tokens="Cameras">Cameras</option>
						<option data-tokens="Electronics">Electronics</option>
						<option data-tokens="Cars">Cars</option>
						<option data-tokens="Bikes">Bikes</option>
						<option data-tokens="Books">Books</option>
					</select>
				</div>
				<div class="search-product ads-list" style="margin-left: 10%">
					<label>Search for a specific product</label>
					<div class="search">
						<div id="custom-search-input">
						<div class="input-group">
							<input type="search" class="form-control input-lg"   name="s2" />
							<span class="input-group-btn">
								<input class="btn btn-info btn-lg" type="submit" value="Search" name="TxtSearch" />
							        
							</span>
						</div>
					</div>
					</div>
				</div>
                </form>
				<div class="clearfix"></div>
			</div>
		</div>	
	</div>
	<div class="ads-display col-md-9">
		<div class="wrapper">					
			<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
					<ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
						<li role="presentation" class="active">
							<a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" 	aria-expanded="true">
							<span class="text">All Ads</span>
						  	</a>
						</li>
					</ul>
					<div id="myTabContent" class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
						   <div>
												<div id="container">
								
								
								<div class="clearfix"></div>
							<ul class="list">
								
							
							
								
<?php
//session_start();  
include("config.php");

if($conn)
{
    $q="";
    $q1="";
  	
    if(isset($_GET['cat']) )
    {
            $cat = $_GET['cat'];
            $q = "SELECT * FROM item_post WHERE catagory = '$cat' 
             AND status = 1 ORDER BY item_id ";
                 //echo $q.'<br>';
           $q1 = "SELECT * FROM item_post WHERE catagory= '$cat'  AND status = 1 ";
        //  echo" if 3";      
    }
    else if( isset($_POST['TxtSearch']) )
 	{
 		$category = $_POST['s1'];
 		$TxtSrch  = $_POST['s2'];
        if( $TxtSrch == "" )
        {
        	$q  ="SELECT * FROM item_post WHERE catagory = '$category'  AND status = 1
        	 ORDER BY item_id ";
	        $q1 ="SELECT * FROM item_post WHERE catagory = '$category'  AND status = 1 
	        ORDER BY item_id ";
        }
        else
        {
        	$q ="SELECT * FROM item_post WHERE catagory = '$category' AND 
	        item_name = '$TxtSrch'  AND status = 1 ORDER BY item_id ";
	        $q1 ="SELECT * FROM item_post WHERE catagory = '$category' AND 
	        item_name = '$TxtSrch'  AND status = 1 ORDER BY item_id ";
        }
        
    }
    else
    {    
        $q = "SELECT * FROM item_post WHERE  status = 1 ";
        $q1 = "SELECT * FROM item_post WHERE  status = 1 ";
    }
    
    $excecute = mysqli_query($conn,$q);

    if($excecute) 
    {
        
    	while( $row = mysqli_fetch_array( $excecute) )
    	{

            $link = 'uploads/'.$row['item_img'];
            $price = $row['price'];
            $item_name = $row['item_name'];
    
            $posted = $row['posted'];
            $descript = $row['decription'];
            $city = $row['city'];

            $rent = $row['rent'];
            $contact = $row['contact'];


            if($rent=='n')
            {
                $rent="Available For Rent";
            }
            else
            {
                $rent="Not Available For Rent";
            }
        	echo'
				<li>
					<img src="'.$link.'" title="" alt="" />
					<section class="list-left">
					<h5 class="title">'.$item_name.'</h5>
					<span class="adprice">Rent Per Day : '.$price.'</span>
                    <span class="adprice">'.$descript.'</span>

					<p class="catpath">'.$rent.'</p>
					</section>
					<section class="list-right">
					<span class="cityname">'.$city.' : ('.$contact.')</span>
					</section>
					<div class="clearfix"></div>
				</li>
			';
    	}
    }
   	$excecute = mysqli_query($conn,$q1);
    
    if($excecute) 
    {
    	$count = 0;
        while( $row = mysqli_fetch_array($excecute))
    	{
        	$count = $count + 1;
    	}
 	}		   
?>

							</ul>
						</div>
							</div>
						</div>
						
						<ul class="pagination pagination-sm">
                     
	<?php        
	for($i=0; $i<ceil($count/3); $i++)
	{        
        echo'    <li><a href="all_ads.php?page='.($i+1).'">'.($i+1).'</a></li>';
	}
}
?>
						</ul>
					  </div>
					</div>
				</div>
				</div>
		<footer>
			<div class="footer-top">
				<div class="container">
					<div class="foo-grids">
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Who We Are</h4>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
							<p>The point of using Lorem Ipsum is that it has a more-or-less normal letters, as opposed to using 'Content here.</p>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Help</h4>
							<ul>
							
								<li><a href="#">Feedback</a></li>
						
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Information</h4>
							<ul>
				 
								<li><a href="#">Privacy Policy</a></li>	
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Contact Us</h4>
							<span class="hq">Our headquarters</span>
							<address>
								<ul class="location">
									<li><span class="glyphicon glyphicon-map-marker"></span></li>
									<li>View hotel Comsats Road</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-earphone"></span></li>
									<li>+0 561 111 235</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-envelope"></span></li>
									<li><a href="mailto:info@example.com">CIITSahiwal@gmail.com</a></li>
									<div class="clearfix"></div>
								</ul>						
							</address>
						</div>
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="footer-bottom text-center">
			<div class="container">
				<div class="footer-logo">
					<a href="index.php"><span>Rent</span>Bazaar</a>
				</div>
				<div class="footer-social-icons">
					<ul>
						<li><a class="facebook" href="#"><span>Facebook</span></a></li>
						<li><a class="twitter" href="#"><span>Twitter</span></a></li>
						<li><a class="googleplus" href="#"><span>Google+</span></a></li>
						
					</ul>
				</div>
				<div class="copyrights">
					<p> © <?php echo date("Y"); ?> Rent Bazaar. All Rights Reserved </p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->
</body>
</html>