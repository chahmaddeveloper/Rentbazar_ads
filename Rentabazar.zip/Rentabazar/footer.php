<footer>
			<div class="footer-top">
				<div class="container">
					<div class="foo-grids">
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Who We Are</h4>
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
							<p>The point of using Lorem Ipsum is that it has a more-or-less normal letters, as opposed to using 'Content here.</p>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Help</h4>
							<ul>
							
								<li><a href="#">Feedback</a></li>
						
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Information</h4>
							<ul>
				 
								<li><a href="#">Privacy Policy</a></li>	
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Contact Us</h4>
							<span class="hq">Our headquarters</span>
							<?php
							$Query = mysqli_query($conn,"SELECT * FROM site_info");
							$DATA = mysqli_fetch_array($Query);
							?>
							<address>
								<ul class="location">
									<li><span class="glyphicon glyphicon-map-marker"></span></li>
									<li><?php echo $DATA['address'] ?></li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-earphone"></span></li>
									<li><?php echo $DATA['mobile'] ?></li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-envelope"></span></li>
									<li><a href="mailto:info@example.com"><?php echo $DATA['email'] ?></a></li>
									<div class="clearfix"></div>
								</ul>						
							</address>
						</div>
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="footer-bottom text-center">
			<div class="container">
				<div class="footer-logo">
					<a href="index.php"><span>Rent</span>Bazaar</a>
				</div>
				<div class="footer-social-icons">
					<ul>
						<li><a class="facebook" href="<?php echo $DATA['facebook'] ?>"><span>Facebook</span></a></li>
						<li><a class="twitter" href="<?php echo $DATA['twitter'] ?>"><span>Twitter</span></a></li>
						<li><a class="googleplus" href="mailto:<?php echo $DATA['gmail'] ?>"><span>Google+</span></a></li>
						
					</ul>
				</div>
				<div class="copyrights">
					<p> © <?php echo date("Y"); ?> Rent Bazaar. All Rights Reserved </p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>