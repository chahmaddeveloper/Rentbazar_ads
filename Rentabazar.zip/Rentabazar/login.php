<?php
session_start();

if (isset($_POST['ls'])) 
{
    echo '<script type="text/javascript">
              alert("SignUp Successfull");
             </script>';
}

if (isset($_POST['login'])) 
{

    $e = $_POST['e'];

    $p = $_POST['p'];

    include("config.php");
    
    if ($conn) 
    {

        $q = "SELECT id,name FROM Info WHERE 
        email ='$e' 
        AND 
        password ='$p'";

        $excecute = mysqli_query($conn, $q);
        if ($excecute) 
        {

            $count = 0;
            $id    = 0;
            while ($row = mysqli_fetch_assoc($excecute)) 
            {
                session_start();
                session_regenerate_id();

                 $_SESSION['id'] = $id = $row['id'];

                $_SESSION['name'] = $row['name'];
                session_write_close();

            }
            if ($id > 0) 
            {
                echo '<script type="text/javascript">
              alert("Login Successfull");
             </script>';
                header("location:index.php");

            }
        }
    }
} 
else
{

    if (!isset($_SESSION['id'])) 
    {

        echo '<script type="text/javascript">
              alert("You Must Login Before Posting An Ad");
             </script>';
    }
}
include("header.php");
?>

     <section>
            <div id="page-wrapper" class="sign-in-wrapper">
                <div class="graphs">
                    <div class="sign-in-form">
                        <div class="sign-in-form-top">
                            <h1>Log in</h1>
                        </div>
                        <div class="signin">
                            <div class="signin-rit">
                                
                                
                                <div class="clearfix"> </div>
                            </div>
                            <form method="post" action="#">
                            <div class="log-input">
                                <div class="log-input-left">
                                   <input type="text" name="e" value="Your Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your Email';}"/>
                                </div>
                            
                                <div class="clearfix"> </div>
                            </div>
                            <div class="log-input">
                                <div class="log-input-left">
                                   <input type="password" name="p" class="lock" value="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
                                </div>
                                
                                <div class="clearfix"> </div>
                            </div>
                            <input type="submit" value="Log in" name="login">
                        </form>     
                        </div>
                        <div class="new_people">
                            <h2>For New People</h2>
                            <p>Having hands on experience in creating innovative designs,I do offer design 
                                solutions which harness.</p>
                            <a href="Register1.php">Register Now!</a>
                        </div>
                    </div>
                </div>
            </div>
        <!--footer section start-->
            <footer class="diff">
               <p class="text-center">&copy <?php echo date("Y"); ?> RentBazaar. All Rights Reserved</p>
            </footer>
        <!--footer section end-->
    </section>
</body>
</html>