<?php
session_start();
if (isset($_POST['register'])) 
{

    $r10 = "";

    $allowed = array(
        'png',
        'jpg',
        'gif'
    );

    if (isset($_FILES['upl']) && $_FILES['upl']['error'] == 0) {

        $extension = pathinfo($_FILES['upl']['name'], PATHINFO_EXTENSION);

        if (!in_array(strtolower($extension), $allowed)) {
            echo '{"status":"error"}';
            exit;
        }

        if (move_uploaded_file($_FILES['upl']['tmp_name'], 'uploads/' . $_FILES['upl']['name'])) {
            echo '{"status":"success"}';
            $r10 = 'upload/' . $_FILES['upl']['name'];

        }
    }

 include("config.php");
 if ($conn) 
 {
    $r1 = $_POST['user'];
    $r2 = $_POST['pass'];
    $r3 = $_POST['mail'];
    $r4 = $_POST['r4'];

    $r6 = $_POST['r6'];

    $r8 = $_POST['r8'];
    $r9 = $_POST['r9'];

    $q   = "INSERT INTO info VALUES(Null, '$r1', '$r2', '$r3', '$r4', '$r6', '$r8', '$r9', 0)";
    $run = mysqli_query($conn, $q);
    if ($run) 
    {

        $_SESSION['ls'] = 1;
        header("location:index.php");
    } 
    else 
    {
        echo '<script type="text/javascript">
          alert("Not Inserted");
         </script>';
        die(print_r(mysqli_error(), true));
    }

   }
}

include("header.php");
?>




     <section>
            <div id="page-wrapper" class="sign-in-wrapper">
                <div class="graphs">
                    <div class="sign-up">
                        <h1>Create an account</h1>
                        <p class="creating">Having hands on experience in creating innovative designs,I do offer design 
                            solutions which harness.</p>
                        <h2>Personal Information</h2>

                        <form method="post" action="Register1.php" enctype="multipart/form-data">
                       <div class="sign-u">
                            <div class="sign-up1">
                                <h4>UserName* :</h4>
                            </div>
                            <div class="sign-up2">
                                
                                    <input type="text" placeholder=" " required=" " name="user"/>
                                
                            </div>
                            <div class="clearfix"> </div>
                        </div>

                        <div class="sign-u">
                            <div class="sign-up1">
                                <h4>Password* :</h4>
                            </div>
                            <div class="sign-up2">
                            
                                    <input type="password" placeholder=" " required=" " name="pass"/>
                                
                            </div>
                            <div class="clearfix"> </div>
                        </div>

                        <div class="sign-u">
                            <div class="sign-up1">
                                <h4>Email* :</h4>
                            </div>
                            <div class="sign-up2">
                                
                                    <input type="text" placeholder=" " required=" " name="mail"/>
                                
                            </div>
                            <div class="clearfix"> </div>
                        </div>

                        <div class="sign-u">
                            <div class="sign-up1">
                                <h4>Contact* :</h4>
                            </div>
                            <div class="sign-up2">
                                
                                    <input type="text" placeholder=" " required=" " name="r4"/>
                                
                            </div>
                            <div class="clearfix"> </div>
                        </div>

                        <h1>Gender</h1>
                        <div class="sign-u">
                            
                            <div class="sign-up2">
                                
                                    <input type="radio" name="r6" value="m" required=" ">Male
                                    <input type="radio" name="r6" value="f" readonly=" ">Female
                                     
                            </div>
                            <div class="clearfix"> </div>
                        </div>
                      


                        <div class="sign-u">
                            <div class="sign-up1">
                                <h4>Adress* :</h4>
                            </div>
                            <div class="sign-up2">
                                
                                    <input type="text" placeholder=" " required=" " name="r8"/>
                                
                            </div>
                            <div class="clearfix"> </div>
                        </div>

                        <div class="sign-u">
                            <div class="sign-up1">
                                <h4>City* :</h4>
                            </div>
                            <div class="sign-up2">
                                
                                    <input type="text" placeholder=" " required=" " name="r9"/>
                                
                            </div>
                            <div class="clearfix"> </div>
                        </div>

                       

                        <div class="sub_home">
                            <div class="sub_home_left">
                                
                                    <input type="submit" value="Create" name="register" id="register">
                                
                            </div>
                        
                            <div class="clearfix"> </div>
                        </div>
                            </form>

                    </div>
                </div>
            </div>
        <!--footer section start-->
            <footer class="diff">
               <p class="text-center">&copy <?php echo date("Y"); ?> RentBazaar. All Rights Reserved </p>
            </footer>
        <!--footer section end-->
    </section>
</body>
</html>