<?php
 
	include("config.php");  
 
	if(mysqli_connect_errno())
	{
		die('Unable to connect to database' . mysqli_connect_error());
	}

	if(!empty($_GET['cat']) && !empty($_GET['in']) )
	{
		$category  = $_GET['cat'];
		$Item_Name = $_GET['in'];
		$stmt = $conn->prepare("SELECT * FROM item_post WHERE catagory = '".$category."' 
		AND item_name = '".$Item_Name."' AND status = 1 ; ");
	}
	else if(!empty($_GET['cat']) && !empty($_GET['ci']) )
	{
		$category  = $_GET['cat'];
		$Item_Name = $_GET['ci'];
		$stmt = $conn->prepare("SELECT * FROM item_post WHERE catagory = '".$category."' 
		AND city = '".$Item_Name."' AND status = 1; ");
	}

	else if(!empty($_GET['cat']) )
	{
		$category  = $_GET['cat'];
		$stmt = $conn->prepare("SELECT * FROM item_post WHERE catagory = '".$category."' AND status = 1; ");
	}
	else
	{
		$stmt = $conn->prepare("SELECT * FROM item_post WHERE  status = 1 ;");
	}

	$stmt->execute();
   
    $stmt->bind_result($item_id, $catagory, $item_name, $decription, $item_img, $price, $city, $name, $contact, $id, $rent, $posted, $status);
    
    $AllAds = array();
    while($stmt->fetch())
  {
    
    $temp['item_id']    = $item_id;
    $temp['catagory']   = $catagory;
    $temp['item_name']  = $item_name;
    $temp['decription'] = $decription;  
    $temp['item_img']   = $item_img;
    $temp['price']      = $price;
    $temp['city']       = $city;
    $temp['name']       = $name;  
    $temp['contact']    = $contact;
    $temp['id']         = $id;
    $temp['rent']       = $rent;
    $temp['posted']     = $posted;
    $temp['status']     = $status;

    array_push($AllAds,$temp);
    
  }   
  echo json_encode($AllAds);


?>