<?php
 
	include("config.php");  
 
	if(mysqli_connect_errno())
	{
		die('Unable to connect to database' . mysqli_connect_error());
	}

	if(!empty($_GET['item_id']) )
	{

		$Id = $_GET['item_id'];

	    $API_Query_Done  = "DELETE FROM item_post WHERE item_id = ".$Id."  ";

		$SignUpAPI_Execute = $conn->prepare($API_Query_Done);
	}
	
	$SignUpAPI_Execute->execute();
   
?>