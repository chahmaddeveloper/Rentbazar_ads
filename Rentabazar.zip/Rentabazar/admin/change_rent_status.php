<?php
session_start();

if (!isset($_SESSION['Admin_id']))
{
    header("location:login.php");
}
else
{
    $item_id=$_GET['item_id'];
    $rent=$_GET['rent'];

  include("config.php");
  if($conn)
  {
    $q ="";
    $q =" UPDATE Item_Post 
    SET rent = '$rent' 
    WHERE item_id ='$item_id'";

    $excecute = mysqli_query($conn,$q);

    if($excecute)
    {
        header("location:".$_SERVER['HTTP_REFERER']);
    }
  }
}

?>

