<?php
session_start();
if(isset($_SESSION['Admin_Name'])) 
{
    $name = $_SESSION['Admin_Name'];    
}
else
{
    header('location:login.php');
}
?>