<?php
 
	include("config.php");  
 
	if(mysqli_connect_errno())
	{
		die('Unable to connect to database' . mysqli_connect_error());
	}

	if(!empty($_GET['p1']) && !empty($_GET['p2']) && !empty($_GET['p3']) )
	{

		$p9 = $_GET['id'];
		$p1 = $_GET['p1'];
	    $p2 = $_GET['p2'];
	    $p3 = $_GET['p3'];
	    $p4 = $_GET['p4'];
	    $p5 = $_GET['p5'];

	    $q1       = "SELECT  * FROM info where id = $p9 ";
        $excecute = mysqli_query($conn, $q1);
        if ($excecute) 
        {
            while ($row = mysqli_fetch_array($excecute)) 
            {      
                $p6 = $row['city'];
                $p7 = $row['name'];
                $p8 = $row['contact'];
            }
        }

	    $API_Query_Done  = "INSERT INTO item_post() VALUES(Null, '$p1','$p2','$p3','$p4', $p5,'$p6','$p7','$p8', 
        $p9, 'n', 0, '".date("Y/m/d")."' )";

		$SignUpAPI_Execute = $conn->prepare($API_Query_Done);
	}
	
	$SignUpAPI_Execute->execute();
   
   	
    
    /*
    $SignUpArray = array();
    
    while($SignUpAPI_Execute->fetch())
  	{
		$temp['item_id']    = $r1;
		$temp['catagory']   = $r2;
		$temp['item_name']  = $r3;
		$temp['decription'] = $r4;  
		$temp['item_img']   = $r6;
		$temp['price']      = $r8;
		$temp['city']       = $r9;
		$temp['status']     = 0;

		array_push($SignUpArray,$temp);
  	}

  	echo json_encode($SignUpArray);
	*/
?>