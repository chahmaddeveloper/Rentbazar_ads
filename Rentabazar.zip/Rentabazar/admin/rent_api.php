<?php
 
	include("config.php");  
 
	if(mysqli_connect_errno())
	{
		die('Unable to connect to database' . mysqli_connect_error());
	}

	if(!empty($_GET['rid']) && !empty($_GET['rs'])  )
	{

		$Id = $_GET['rid'];
	    $St = $_GET['rs'];

	    $API_Query_Done  = "UPDATE item_post SET 
	    rent = '".$St."' WHERE item_id = ".$Id."  ";

		$SignUpAPI_Execute = $conn->prepare($API_Query_Done);
	}
	
	$SignUpAPI_Execute->execute();
   
?>