<?php
session_start();
if(!isset($_SESSION['Admin_id']))
{
    header("location:login.php");
}
else
{
  include("config.php");
  echo $item_id = $_GET['item_id'];
  $conn = mysqli_connect("localhost", "root", "", "rentbazaar");    
  if($conn)
  {
    $q="";
    $q=" DELETE FROM item_post  WHERE item_id = '$item_id'";
    $excecute= mysqli_query($conn,$q);
    if($excecute)
    {
        header("location:".$_SERVER['HTTP_REFERER']);
    }
  }
}












?>

