<?php
include('session.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> Pic </th>
            <th>Description </th>
            <th>Rent Per Day </th>
            <th>Available </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
    <?php
    include("config.php");     
    if($conn)
    {
        
        if(isset($_GET['cat']) )
        {
            $cat = $_GET['cat'];
            $q = "SELECT * FROM item_post WHERE catagory = '$cat' AND status = 1 ORDER BY item_id ";
        }
        else
        {    
            $q = "SELECT * FROM item_post WHERE status = 1";
        }
        $excecute = mysqli_query($conn,$q);
        
        while( $row = mysqli_fetch_array( $excecute) )
        {

            $link = $row['item_img'];
            $link = '../uploads/'.$link;
            $price = $row['price'];
            $item_name = $row['item_name'];   
            $posted = $row['posted'];
            $descript = $row['decription'];
            $city = $row['city'];
            $rent = $row['rent'];
            $item_id = $row['item_id'];
            $contact = $row['contact'];
            $status = $row['status'];
        ?>
          <tr>
            <td> <img style="width: 50px; height: 50px;" src="<?php echo $link; ?>" /> </td>
            <td> <?php echo $descript; ?></td>
            <td> <?php echo $price; ?> </td>
            <?php
            if($rent=='n')
            {
            ?>
              <td>
                <a href="change_rent_status.php?item_id=<?= $item_id?>&rent=y">
                  <h4> Rent(Yes)</h4>  
                </a>
              </td>
            <?php
            }
            else
            {
            ?>
              <td>  
                <a href="change_rent_status.php?item_id=<?= $item_id; ?>&rent=n">
                  <h4> Rent(No)</h4>  
                </a>
              </td>
            <?php
            }
            ?>
            <td>
                <a href="delete_ad.php?item_id=<?= $item_id;?>"><h4>Delete Ad</h4>  </a>
            </td>
          </tr>
        <?php
        }
      }
        ?>
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>