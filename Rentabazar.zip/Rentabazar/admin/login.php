<?php
session_start();

if (isset($_POST['login'])) 
{

    $e = $_POST['e'];

    $p = $_POST['p'];

    include("config.php");

    if ($conn) 
    {

        $q = "SELECT id,name FROM Info WHERE 
        email ='$e' and 
        password ='$p'
        AND status = 1
        ";
        $excecute = mysqli_query($conn, $q);
        if ($excecute) 
        {

            $count = 0;
            $id    = 0;
            while ($row = mysqli_fetch_array($excecute)) 
            {

                $_SESSION['Admin_id'] =$id = $row['id'];

                $_SESSION['Admin_Name'] = $row['name'];

                header("location:all_ads.php");
            }
        }
    }
} 
?>
<!DOCTYPE html>
<html>
<head>
<title> Login</title>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/bootstrap-select.css">
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->    
<!-- js -->
<script type="text/javascript" src="../js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../js/bootstrap.min.js"></script>
<script src="../js/bootstrap-select.js"></script>
<script type="text/javascript" src="../js/jquery.leanModal.min.js"></script>
<link href="../css/jquery.uls.css" rel="stylesheet"/>
<link href="../css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="../css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="../js/jquery.uls.data.js"></script>
<script src="../js/jquery.uls.data.utils.js"></script>
<script src="../js/jquery.uls.lcd.js"></script>
</head>
<body>
<div class="header">
     <section>
            <div id="page-wrapper" class="sign-in-wrapper">
                <div class="graphs">
                    <div class="sign-in-form">
                        <div class="sign-in-form-top" style="margin-top: 50px;">
                            <h1>Administration Login</h1>
                        </div>
                        <div class="signin">
                            <div class="signin-rit">
                                
                                
                                <div class="clearfix"> </div>
                            </div>
                            <form method="post" action="#">
                            <div class="log-input">
                                <div class="log-input-left">
                                   <input type="text" name="e" value="Your Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your Email';}"/>
                                </div>
                            
                                <div class="clearfix"> </div>
                            </div>
                            <div class="log-input">
                                <div class="log-input-left">
                                   <input type="password" name="p" class="lock" value="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email address:';}"/>
                                </div>
                                
                                <div class="clearfix"> </div>
                            </div>
                            <input type="submit" value="Log in" name="login">
                        </form>     
                        </div>
                        <div style="height: 180px;">
                    </div>
                </div>
            </div>
    </section>
</body>
</html>