<?php
 
	include("config.php");  
 
	if(mysqli_connect_errno())
	{
		die('Unable to connect to database' . mysqli_connect_error());
	}

	if(!empty($_GET['r1']) && !empty($_GET['r2']) && !empty($_GET['r3']) )
	{

		$r1 = $_GET['r1'];
	    $r2 = $_GET['r2'];
	    $r3 = $_GET['r3'];
	    $r4 = $_GET['r4'];

	    $r6 = $_GET['r6'];

	    $r8 = $_GET['r8'];
	    $r9 = $_GET['r9'];

	    $API_Query_Done  = "INSERT INTO info() 
	    VALUES(
	    	Null, '$r1', '$r2', '$r3', '$r4', 
	    	'$r6', '$r8', '$r9', 0
		)";

		$SignUpAPI_Execute = $conn->prepare($API_Query_Done);
	}
	
	$SignUpAPI_Execute->execute();
   
   	
    
    /*
    $SignUpArray = array();
    
    while($SignUpAPI_Execute->fetch())
  	{
		$temp['item_id']    = $r1;
		$temp['catagory']   = $r2;
		$temp['item_name']  = $r3;
		$temp['decription'] = $r4;  
		$temp['item_img']   = $r6;
		$temp['price']      = $r8;
		$temp['city']       = $r9;
		$temp['status']     = 0;

		array_push($SignUpArray,$temp);
  	}

  	echo json_encode($SignUpArray);
	*/
?>