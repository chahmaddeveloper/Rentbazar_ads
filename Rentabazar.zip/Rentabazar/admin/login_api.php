<?php
 
 include("config.php");  
 if(mysqli_connect_errno())
 {
   
   die('Unable to connect to database' . mysqli_connect_error());
 }

    if(!empty($_GET['e']) && !empty($_GET['p']))
    {
      $stmt = $conn->prepare("SELECT id, name, password, email, status FROM info
        WHERE email = '".$_GET['e']."' AND password = '".$_GET['p']."' ;");  
    
      $stmt->execute();
   
      $stmt->bind_result($id, $name, $password, $email, $status);
    }
    $AllAds = array();
    while($stmt->fetch())
  {
    
    $temp['id']        = $id;
    $temp['name']      = $name;
    $temp['password']  = $password;
    $temp['email']     = $email;  
    $temp['status']    = $status;

    array_push($AllAds,$temp);
    
  }   
  echo json_encode($AllAds);


?>